#!/usr/bin/env bash
# Quick bash version test

echo "Current bash version: ${BASH_VERSION}"
echo "Major version: ${BASH_VERSION%%.*}"

if [[ "${BASH_VERSION%%.*}" -ge 5 ]]; then
    echo "✓ Bash 5.0+ detected"
else
    echo "✗ Bash version too old"
fi

# Test associative arrays
if declare -A test_array 2>/dev/null; then
    echo "✓ Associative arrays supported"
else
    echo "✗ Associative arrays not supported"
fi

# Check deployment scripts
for script in scripts/aws-deployment-modular.sh scripts/aws-deployment-v2-simple.sh; do
    if [[ -f "$script" ]]; then
        if grep -qE "(MINIMUM_BASH_VERSION|BASH_MAJOR|bash.*5\.[0-9])" "$script"; then
            echo "✓ $script has version check"
        else
            echo "✗ $script missing version check"
        fi
    fi
done