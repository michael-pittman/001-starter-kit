# Coding Standards

## Core Standards
- **Languages & Runtimes:** Bash 5.3+, AWS CLI latest
- **Style & Linting:** ShellCheck for bash validation
- **Test Organization:** Unit tests in `tests/unit/`, integration in `tests/integration/`

## Naming Conventions

| Element | Convention | Example |
|---------|------------|---------|
| Functions | `[action]_[resource]_[specific_action]` | `create_vpc_infrastructure()` |
| Variables | `[MODULE]_[RESOURCE]_[PROPERTY]` | `VPC_ID`, `EC2_INSTANCE_TYPE` |
| Files | `[module]-[purpose].sh` | `vpc-management.sh` |
| Directories | `[purpose]/` | `infrastructure/`, `deployment/` |

## Critical Rules
- **Error Handling:** All functions must include error handling and logging
- **Library Usage:** All scripts must use the modular library system
- **Progress Tracking:** All long-running operations must show progress
- **State Management:** All deployment state changes must be persisted
- **Validation:** All inputs must be validated before processing
- **Documentation:** All functions must include inline documentation

## Language-Specific Guidelines

### Bash Specifics
- **Shebang:** Always use `#!/usr/bin/env bash`
- **Error Handling:** Use `set -euo pipefail` for strict error handling
- **Arrays:** Use associative arrays for complex data structures
- **Functions:** Use local variables and proper parameter handling 