# Tech Stack

## Cloud Infrastructure
- **Provider:** AWS (Amazon Web Services)
- **Key Services:** EC2, VPC, ALB, CloudFront, EFS, IAM, CloudWatch, S3
- **Deployment Regions:** us-east-1 (primary), us-west-2 (backup)

## Technology Stack Table

| Category | Technology | Version | Purpose | Rationale |
|----------|------------|---------|---------|-----------|
| **Scripting Language** | Bash | 5.3+ | Primary development language | Native Unix/Linux support, AWS CLI integration, team expertise |
| **Cloud Provider** | AWS | Latest | Infrastructure platform | Comprehensive service ecosystem, cost optimization, team familiarity |
| **Infrastructure as Code** | CloudFormation | Latest | Resource provisioning | Native AWS integration, declarative syntax, version control |
| **Container Platform** | Docker | 24.0+ | Application containerization | Consistent deployment environments, portability, industry standard |
| **Version Control** | Git | 2.40+ | Source code management | Industry standard, branching strategies, collaboration tools |
| **CLI Framework** | Custom Bash | N/A | Command-line interface | Tailored to deployment workflows, progress indicators, user experience |
| **Logging** | Structured Logging | Custom | Application logging | Consistent format, timestamps, module tags, debugging support |
| **Error Handling** | Custom Error System | N/A | Error management | Uniform error codes, recovery mechanisms, user-friendly messages |
| **Testing** | Bash Test Framework | Custom | Automated testing | Unit tests, integration tests, deployment validation |
| **Monitoring** | CloudWatch | Latest | Infrastructure monitoring | Native AWS integration, metrics collection, alerting | 