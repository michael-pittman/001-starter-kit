# Database Schema

## Configuration Storage (JSON Files)

```json
{
  "deployment_config": {
    "stack_name": "string",
    "deployment_type": "enum(spot|alb|cdn|full)",
    "environment": "enum(dev|staging|prod)",
    "aws_region": "string",
    "aws_profile": "string",
    "resources": {
      "vpc": {
        "cidr_block": "string",
        "subnets": [
          {
            "name": "string",
            "cidr": "string",
            "type": "enum(public|private)"
          }
        ]
      },
      "compute": {
        "instance_type": "string",
        "ami_id": "string",
        "key_name": "string",
        "security_groups": ["string"]
      },
      "alb": {
        "scheme": "enum(internet-facing|internal)",
        "type": "enum(application|network)",
        "target_groups": [
          {
            "name": "string",
            "port": "number",
            "protocol": "string"
          }
        ]
      },
      "cdn": {
        "origin_domain": "string",
        "behaviors": [
          {
            "path_pattern": "string",
            "cache_policy": "string"
          }
        ]
      }
    }
  }
}
```

## State Management (JSON Files)

```json
{
  "deployment_state": {
    "deployment_id": "string",
    "stack_name": "string",
    "status": "enum(initializing|in_progress|completed|failed|rolling_back)",
    "start_time": "timestamp",
    "end_time": "timestamp",
    "current_step": "string",
    "progress": "number",
    "resources": {
      "created": ["string"],
      "failed": ["string"],
      "deleted": ["string"]
    },
    "errors": [
      {
        "step": "string",
        "message": "string",
        "timestamp": "timestamp"
      }
    ]
  }
}
``` 