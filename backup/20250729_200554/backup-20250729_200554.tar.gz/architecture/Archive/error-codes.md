# Error Codes Documentation

## Overview

This document describes the standardized error codes used across all modules in the GeuseMaker project. All error codes follow a hierarchical numbering system to facilitate error classification, handling, and recovery.

## Error Code Hierarchy

### General Errors (1-99)
Used for basic system errors and common issues.

| Code | Constant | Description | Recovery Action |
|------|----------|-------------|-----------------|
| 0 | `ERROR_SUCCESS` | Operation completed successfully | N/A |
| 1 | `ERROR_GENERAL` | General error occurred | Check logs for details |
| 2 | `ERROR_INVALID_ARGUMENT` | Invalid argument provided | Verify input parameters |
| 3 | `ERROR_MISSING_DEPENDENCY` | Required dependency not found | Install missing dependency |
| 4 | `ERROR_PERMISSION_DENIED` | Permission denied | Check user permissions |
| 5 | `ERROR_FILE_NOT_FOUND` | File not found | Verify file path and existence |
| 6 | `ERROR_TIMEOUT` | Operation timed out | Retry with longer timeout |
| 7 | `ERROR_INTERRUPTED` | Operation interrupted | Retry operation |

### Configuration Errors (100-199)
Used for configuration-related issues.

| Code | Constant | Description | Recovery Action |
|------|----------|-------------|-----------------|
| 100 | `ERROR_CONFIG_INVALID` | Invalid configuration | Review configuration file |
| 101 | `ERROR_CONFIG_MISSING` | Configuration file missing | Create or restore configuration |
| 102 | `ERROR_CONFIG_PARSE` | Configuration parse error | Fix syntax errors in config |
| 103 | `ERROR_CONFIG_VALIDATION` | Configuration validation failed | Correct configuration values |

### AWS Errors (200-299)
Used for AWS-specific errors and API issues.

| Code | Constant | Description | Recovery Action |
|------|----------|-------------|-----------------|
| 200 | `ERROR_AWS_CREDENTIALS` | AWS credentials not found or invalid | Configure AWS credentials |
| 201 | `ERROR_AWS_PERMISSION` | AWS permission denied | Check IAM roles and policies |
| 202 | `ERROR_AWS_QUOTA_EXCEEDED` | AWS service quota exceeded | Request quota increase or wait |
| 203 | `ERROR_AWS_RESOURCE_NOT_FOUND` | AWS resource not found | Verify resource exists |
| 204 | `ERROR_AWS_RESOURCE_EXISTS` | AWS resource already exists | Use existing resource or delete first |
| 205 | `ERROR_AWS_API_ERROR` | AWS API error | Check AWS service status |
| 206 | `ERROR_AWS_REGION_INVALID` | Invalid AWS region | Use valid region |
| 207 | `ERROR_AWS_PROFILE_INVALID` | Invalid AWS profile | Configure valid profile |

### Deployment Errors (300-399)
Used for deployment and orchestration issues.

| Code | Constant | Description | Recovery Action |
|------|----------|-------------|-----------------|
| 300 | `ERROR_DEPLOYMENT_FAILED` | Deployment failed | Check deployment logs |
| 301 | `ERROR_DEPLOYMENT_TIMEOUT` | Deployment timed out | Retry deployment |
| 302 | `ERROR_DEPLOYMENT_ROLLBACK` | Deployment rollback failed | Manual intervention required |
| 303 | `ERROR_DEPLOYMENT_VALIDATION` | Deployment validation failed | Fix validation issues |
| 304 | `ERROR_DEPLOYMENT_STATE` | Invalid deployment state | Reset deployment state |
| 305 | `ERROR_DEPLOYMENT_CONFLICT` | Deployment conflict detected | Resolve conflicts |

### Infrastructure Errors (400-499)
Used for infrastructure resource creation and management.

| Code | Constant | Description | Recovery Action |
|------|----------|-------------|-----------------|
| 400 | `ERROR_VPC_CREATION` | VPC creation failed | Check VPC limits and permissions |
| 401 | `ERROR_SUBNET_CREATION` | Subnet creation failed | Verify CIDR ranges |
| 402 | `ERROR_SECURITY_GROUP_CREATION` | Security group creation failed | Check security group limits |
| 403 | `ERROR_INSTANCE_CREATION` | Instance creation failed | Check instance limits and AMI |
| 404 | `ERROR_LOAD_BALANCER_CREATION` | Load balancer creation failed | Check ALB limits |
| 405 | `ERROR_AUTO_SCALING_CREATION` | Auto scaling group creation failed | Check ASG configuration |
| 406 | `ERROR_EFS_CREATION` | EFS creation failed | Check EFS limits |
| 407 | `ERROR_CLOUDFRONT_CREATION` | CloudFront creation failed | Check CloudFront configuration |

### Validation Errors (500-599)
Used for input and data validation issues.

| Code | Constant | Description | Recovery Action |
|------|----------|-------------|-----------------|
| 500 | `ERROR_VALIDATION_FAILED` | Validation failed | Review validation rules |
| 501 | `ERROR_VALIDATION_INPUT` | Invalid input | Correct input format |
| 502 | `ERROR_VALIDATION_FORMAT` | Invalid format | Use correct format |
| 503 | `ERROR_VALIDATION_RANGE` | Value out of range | Use value within range |
| 504 | `ERROR_VALIDATION_REQUIRED` | Required field missing | Provide required field |

### Network Errors (600-699)
Used for network connectivity and communication issues.

| Code | Constant | Description | Recovery Action |
|------|----------|-------------|-----------------|
| 600 | `ERROR_NETWORK_TIMEOUT` | Network timeout | Check network connectivity |
| 601 | `ERROR_NETWORK_CONNECTION` | Network connection failed | Verify network configuration |
| 602 | `ERROR_NETWORK_DNS` | DNS resolution failed | Check DNS configuration |
| 603 | `ERROR_NETWORK_FIREWALL` | Firewall blocked connection | Configure firewall rules |

## Usage Guidelines

### Error Code Selection

1. **Choose the most specific error code** that matches the error condition
2. **Use AWS error codes (200-299)** for AWS API errors
3. **Use infrastructure error codes (400-499)** for resource creation failures
4. **Use validation error codes (500-599)** for input validation issues
5. **Use general error codes (1-99)** as fallback for unclassified errors

### Error Message Format

Error messages should be:
- **Clear and actionable**: Provide specific guidance on how to resolve the issue
- **Include context**: Mention the operation, resource, or parameter that failed
- **User-friendly**: Avoid technical jargon when possible

Example:
```bash
# Good
throw_error $ERROR_AWS_PERMISSION "Permission denied for S3 bucket 'my-bucket' - check IAM policies"

# Bad
throw_error $ERROR_AWS_PERMISSION "AccessDenied"
```

### Error Recovery

1. **Recoverable errors** (timeouts, quota exceeded) should be retried automatically
2. **Non-recoverable errors** (permission denied, missing dependencies) should fail fast
3. **Use exponential backoff** for retryable operations
4. **Log all errors** with appropriate context for debugging

### Error Handling Patterns

```bash
# Standard error handling pattern
if ! some_operation; then
    local error_code
    case $? in
        1) error_code=$ERROR_AWS_PERMISSION ;;
        2) error_code=$ERROR_TIMEOUT ;;
        *) error_code=$ERROR_GENERAL ;;
    esac
    throw_error $error_code "Operation failed: $operation_name"
fi

# AWS error handling
aws s3 ls s3://my-bucket 2>&1 | while read -r line; do
    if [[ $line =~ "AccessDenied" ]]; then
        throw_error $ERROR_AWS_PERMISSION "Access denied for S3 bucket"
    elif [[ $line =~ "NoSuchBucket" ]]; then
        throw_error $ERROR_AWS_RESOURCE_NOT_FOUND "S3 bucket not found"
    fi
done
```

## Error Code Validation

All error codes are validated through the test suite in `tests/unit/test-error-handling.sh`. The tests verify:

1. **Error code hierarchy** is properly categorized
2. **Error messages** are user-friendly and actionable
3. **Error recovery** mechanisms work correctly
4. **Performance** is within acceptable limits

## Migration Guide

When adding new error codes:

1. **Choose the appropriate category** based on the error type
2. **Use the next available number** in the category range
3. **Add the constant** to `lib/modules/core/errors.sh`
4. **Add the message** to the `get_error_message()` function
5. **Update this documentation** with the new error code
6. **Add test cases** to verify the new error code works correctly

## Best Practices

1. **Never use hardcoded error numbers** - always use the defined constants
2. **Provide meaningful error messages** that help users resolve the issue
3. **Log errors with context** for debugging purposes
4. **Handle errors gracefully** with appropriate recovery mechanisms
5. **Test error conditions** to ensure proper error handling
6. **Document error scenarios** in user guides and troubleshooting docs