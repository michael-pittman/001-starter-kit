# Data Models

## Deployment Configuration
**Purpose:** Centralized configuration management for deployment parameters and settings

**Key Attributes:**
- `stack_name`: string - Unique identifier for the deployment stack
- `deployment_type`: enum - Type of deployment (spot, alb, cdn, full)
- `environment`: enum - Target environment (dev, staging, prod)
- `aws_region`: string - AWS region for resource deployment
- `aws_profile`: string - AWS credentials profile to use

**Relationships:**
- Contains multiple resource configurations
- References environment-specific variables
- Links to deployment state tracking

## Deployment State
**Purpose:** Track the current state and progress of deployment operations

**Key Attributes:**
- `deployment_id`: string - Unique identifier for deployment session
- `status`: enum - Current deployment status (initializing, in_progress, completed, failed, rolling_back)
- `start_time`: timestamp - When deployment began
- `end_time`: timestamp - When deployment completed or failed
- `current_step`: string - Current deployment step being executed
- `error_messages`: array - Collection of error messages if deployment failed

**Relationships:**
- Associated with deployment configuration
- Tracks progress through deployment steps
- Links to rollback information

## Resource Configuration
**Purpose:** Define configuration parameters for AWS resources

**Key Attributes:**
- `resource_type`: enum - Type of AWS resource (vpc, ec2, alb, cloudfront)
- `resource_name`: string - Name identifier for the resource
- `configuration`: object - Resource-specific configuration parameters
- `dependencies`: array - List of resources this resource depends on
- `tags`: object - AWS tags to apply to the resource

**Relationships:**
- Belongs to deployment configuration
- May depend on other resources
- Links to actual AWS resources when deployed 