# External APIs

## AWS CLI API
- **Purpose:** Primary interface for AWS resource management and deployment
- **Documentation:** https://docs.aws.amazon.com/cli/latest/reference/
- **Base URL(s):** AWS service endpoints (region-specific)
- **Authentication:** AWS credentials (access keys, IAM roles, profiles)
- **Rate Limits:** AWS service-specific limits

**Key Endpoints Used:**
- `aws ec2` - EC2 instance and resource management
- `aws vpc` - VPC and networking configuration
- `aws elbv2` - Application Load Balancer management
- `aws cloudfront` - CDN distribution management
- `aws cloudwatch` - Monitoring and metrics collection

**Integration Notes:** All AWS operations use AWS CLI with proper credential management and error handling

## Docker API
- **Purpose:** Container management and deployment
- **Documentation:** https://docs.docker.com/engine/api/
- **Base URL(s):** Local Docker daemon (unix:///var/run/docker.sock)
- **Authentication:** Local Docker daemon access
- **Rate Limits:** None (local operations)

**Key Endpoints Used:**
- `docker build` - Container image building
- `docker run` - Container execution
- `docker ps` - Container status monitoring
- `docker logs` - Container log access

**Integration Notes:** Docker operations are used for application containerization and deployment 