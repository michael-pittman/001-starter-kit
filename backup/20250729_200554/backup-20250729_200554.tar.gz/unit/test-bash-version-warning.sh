#!/usr/bin/env bash
# =============================================================================
# Unit Test: Bash Version Warning System
# Tests the check_bash_version() function to ensure it warns but doesn't exit
# =============================================================================

set -euo pipefail

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
LIB_DIR="$PROJECT_ROOT/lib"

# Test framework
source "$SCRIPT_DIR/../lib/shell-test-framework.sh"

# Source the errors module
source "$LIB_DIR/modules/core/errors.sh"

# Initialize tests
test_init

# Test 1: Function always returns 0
test_always_returns_zero() {
    test_start "test_always_returns_zero"
    
    # Save original BASH_VERSION
    local original_version="$BASH_VERSION"
    
    # Test with various bash versions
    local test_versions=(
        "3.2.57(1)-release"    # macOS default
        "4.4.23(1)-release"    # Ubuntu 18.04
        "5.0.17(1)-release"    # Ubuntu 20.04
        "5.1.16(1)-release"    # Recent version
        "5.3.0(1)-release"     # Minimum recommended
        "5.3.3(1)-release"     # Fully recommended
        "6.0.0(1)-release"     # Future version
    )
    
    for version in "${test_versions[@]}"; do
        # Mock BASH_VERSION
        BASH_VERSION="$version"
        
        # Call check_bash_version and verify it returns 0
        if check_bash_version; then
            assert_true true "check_bash_version returned 0 for version $version"
        else
            assert_fail "check_bash_version did not return 0 for version $version"
        fi
    done
    
    # Restore original version
    BASH_VERSION="$original_version"
    
    test_pass "Function always returns 0"
}

# Test 2: Warning messages for old versions
test_warning_messages_old_versions() {
    test_start "test_warning_messages_old_versions"
    
    # Save original BASH_VERSION
    local original_version="$BASH_VERSION"
    
    # Test versions that should trigger warnings
    local old_versions=(
        "3.2.57(1)-release"
        "4.4.23(1)-release"
        "5.0.17(1)-release"
        "5.2.15(1)-release"
    )
    
    for version in "${old_versions[@]}"; do
        # Mock BASH_VERSION
        BASH_VERSION="$version"
        
        # Capture stderr output
        local warning_output
        warning_output=$(check_bash_version 2>&1 >/dev/null)
        
        # Check that warning was displayed
        if [[ "$warning_output" =~ "WARNING:" ]]; then
            assert_true true "Warning displayed for version $version"
        else
            assert_fail "No warning displayed for version $version"
        fi
        
        # Check for upgrade instructions
        if [[ "$warning_output" =~ "brew install bash" ]]; then
            assert_true true "macOS upgrade instructions present"
        else
            assert_fail "macOS upgrade instructions missing"
        fi
    done
    
    # Restore original version
    BASH_VERSION="$original_version"
    
    test_pass "Warning messages displayed correctly"
}

# Test 3: No warnings for supported versions
test_no_warnings_supported_versions() {
    test_start "test_no_warnings_supported_versions"
    
    # Save original BASH_VERSION
    local original_version="$BASH_VERSION"
    
    # Test versions that should NOT trigger warnings
    local supported_versions=(
        "5.3.0(1)-release"
        "5.3.3(1)-release"
        "5.4.0(1)-release"
        "6.0.0(1)-release"
    )
    
    for version in "${supported_versions[@]}"; do
        # Mock BASH_VERSION
        BASH_VERSION="$version"
        
        # Capture stderr output
        local warning_output
        warning_output=$(check_bash_version 2>&1 >/dev/null)
        
        # Check that NO warning was displayed
        if [[ -z "$warning_output" ]]; then
            assert_true true "No warning for version $version"
        else
            assert_fail "Unexpected warning for version $version: $warning_output"
        fi
    done
    
    # Restore original version
    BASH_VERSION="$original_version"
    
    test_pass "No warnings for supported versions"
}

# Test 4: Handle missing BASH_VERSION
test_handle_missing_bash_version() {
    test_start "test_handle_missing_bash_version"
    
    # Save original BASH_VERSION
    local original_version="$BASH_VERSION"
    
    # Unset BASH_VERSION
    unset BASH_VERSION
    
    # Capture stderr output
    local warning_output
    warning_output=$(check_bash_version 2>&1 >/dev/null)
    
    # Check return code is 0
    check_bash_version
    local return_code=$?
    assert_equals "$return_code" "0" "Function returns 0 even with missing BASH_VERSION"
    
    # Check warning message
    if [[ "$warning_output" =~ "Unable to determine bash version" ]]; then
        assert_true true "Warning displayed for missing BASH_VERSION"
    else
        assert_fail "No warning for missing BASH_VERSION"
    fi
    
    # Restore original version
    BASH_VERSION="$original_version"
    
    test_pass "Handles missing BASH_VERSION gracefully"
}

# Test 5: Version extraction logic
test_version_extraction() {
    test_start "test_version_extraction"
    
    # Save original BASH_VERSION
    local original_version="$BASH_VERSION"
    
    # Test various version formats
    local version_tests=(
        "5.3.0(1)-release:5:3"
        "5.2.15(1)-release:5:2"
        "4.4.23(2)-release:4:4"
        "3.2.57(1)-release:3:2"
    )
    
    for test_case in "${version_tests[@]}"; do
        IFS=':' read -r version expected_major expected_minor <<< "$test_case"
        
        # Mock BASH_VERSION
        BASH_VERSION="$version"
        
        # Extract version components like the function does
        local bash_major="${BASH_VERSION%%.*}"
        local bash_minor="${BASH_VERSION#*.}"
        bash_minor="${bash_minor%%.*}"
        
        assert_equals "$bash_major" "$expected_major" "Major version extraction for $version"
        assert_equals "$bash_minor" "$expected_minor" "Minor version extraction for $version"
    done
    
    # Restore original version
    BASH_VERSION="$original_version"
    
    test_pass "Version extraction works correctly"
}

# Test 6: Installation instructions
test_installation_instructions() {
    test_start "test_installation_instructions"
    
    # Save original BASH_VERSION
    local original_version="$BASH_VERSION"
    
    # Use old version to trigger warning
    BASH_VERSION="3.2.57(1)-release"
    
    # Capture stderr output
    local warning_output
    warning_output=$(check_bash_version 2>&1 >/dev/null)
    
    # Check for all platform instructions
    local platforms=(
        "macOS:.*brew install bash"
        "Ubuntu:.*sudo apt update"
        "RHEL:.*sudo yum install bash"
        "Amazon:.*sudo yum install bash"
        "Alpine:.*apk add bash"
    )
    
    for platform_pattern in "${platforms[@]}"; do
        if [[ "$warning_output" =~ $platform_pattern ]]; then
            assert_true true "Instructions for ${platform_pattern%%:*} present"
        else
            assert_fail "Instructions for ${platform_pattern%%:*} missing"
        fi
    done
    
    # Check for documentation reference
    if [[ "$warning_output" =~ "docs/OS-COMPATIBILITY.md" ]]; then
        assert_true true "Documentation reference present"
    else
        assert_fail "Documentation reference missing"
    fi
    
    # Restore original version
    BASH_VERSION="$original_version"
    
    test_pass "Installation instructions complete"
}

# Test 7: Integration with scripts
test_script_integration() {
    test_start "test_script_integration"
    
    # Create a test script that uses check_bash_version
    local test_script="$TEST_TMP/integration_test.sh"
    cat > "$test_script" << 'EOF'
#!/usr/bin/env bash
set -euo pipefail

# Mock old bash version
BASH_VERSION="3.2.57(1)-release"

# Source errors module
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$(dirname "$SCRIPT_DIR")/lib/modules/core/errors.sh"

# Check version
check_bash_version

# Continue with script execution
echo "Script continues after version check"
exit 0
EOF
    
    chmod +x "$test_script"
    
    # Run the script and capture output
    local output
    output=$("$test_script" 2>&1)
    local exit_code=$?
    
    # Verify script completed successfully
    assert_equals "$exit_code" "0" "Script exits with 0"
    
    # Verify warning was displayed
    if [[ "$output" =~ "WARNING:" ]]; then
        assert_true true "Warning displayed in script"
    else
        assert_fail "No warning displayed in script"
    fi
    
    # Verify script continued execution
    if [[ "$output" =~ "Script continues after version check" ]]; then
        assert_true true "Script continued after version check"
    else
        assert_fail "Script did not continue after version check"
    fi
    
    test_pass "Script integration works correctly"
}

# Test 8: Logging integration
test_logging_integration() {
    test_start "test_logging_integration"
    
    # Save original BASH_VERSION
    local original_version="$BASH_VERSION"
    
    # Mock log_warn function to capture calls
    local log_warn_called=false
    local log_warn_message=""
    log_warn() {
        log_warn_called=true
        log_warn_message="$1"
    }
    
    # Use old version
    BASH_VERSION="4.4.0(1)-release"
    
    # Call check_bash_version
    check_bash_version >/dev/null 2>&1
    
    # Check if log_warn was called (when available)
    if command -v log_warn >/dev/null 2>&1; then
        if [[ "$log_warn_called" == "true" ]]; then
            assert_true true "log_warn was called"
        else
            assert_true true "log_warn might not be available in test context"
        fi
    fi
    
    # Restore original version
    BASH_VERSION="$original_version"
    
    test_pass "Logging integration tested"
}

# Run all tests
test_always_returns_zero
test_warning_messages_old_versions
test_no_warnings_supported_versions
test_handle_missing_bash_version
test_version_extraction
test_installation_instructions
test_script_integration
test_logging_integration

# Print summary
test_summary