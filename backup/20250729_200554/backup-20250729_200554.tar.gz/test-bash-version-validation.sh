#!/usr/bin/env bash
# Test bash version validation functionality
# Tests the version checking and validation across different scenarios

set -euo pipefail

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
LIB_DIR="$PROJECT_ROOT/lib"

# Test framework
source "$SCRIPT_DIR/lib/shell-test-framework.sh"

# Initialize tests
test_init

# Test minimum version validation
test_minimum_version_validation() {
    test_start "test_minimum_version_validation"
    
    # Test version comparison logic
    local test_cases=(
        "5.3.0:5.3.0:true"    # Equal versions
        "5.3.0:5.2.0:true"    # Higher than minimum
        "5.3.0:5.4.0:false"   # Lower than minimum
        "5.0.0:4.4.0:true"    # Major version higher
        "4.4.0:5.0.0:false"   # Major version lower
        "5.3.1:5.3.0:true"    # Patch version higher
        "5.3.0:5.3.1:false"   # Patch version lower
    )
    
    for test_case in "${test_cases[@]}"; do
        IFS=':' read -r min_version test_version expected <<< "$test_case"
        
        # Create test script
        cat > "$TEST_TMP/version_test.sh" << EOF
#!/usr/bin/env bash
MINIMUM_BASH_VERSION="$min_version"

# Mock BASH_VERSION
BASH_VERSION="$test_version"

# Version comparison function
version_compare() {
    local v1=\$1 v2=\$2
    local IFS=.
    local i v1_parts=(\$v1) v2_parts=(\$v2)
    
    # Fill empty positions with zeros
    for ((i=\${#v1_parts[@]}; i<\${#v2_parts[@]}; i++)); do
        v1_parts[i]=0
    done
    
    for ((i=0; i<\${#v1_parts[@]}; i++)); do
        if [[ -z \${v2_parts[i]} ]]; then
            v2_parts[i]=0
        fi
        
        if ((10#\${v1_parts[i]} > 10#\${v2_parts[i]})); then
            return 0
        fi
        
        if ((10#\${v1_parts[i]} < 10#\${v2_parts[i]})); then
            return 1
        fi
    done
    
    return 0
}

# Check version
if version_compare "\$BASH_VERSION" "\$MINIMUM_BASH_VERSION"; then
    echo "PASS"
else
    echo "FAIL"
fi
EOF
        
        chmod +x "$TEST_TMP/version_test.sh"
        local result=$("$TEST_TMP/version_test.sh")
        
        if [[ "$expected" == "true" ]]; then
            assert_equals "$result" "PASS" "Version $test_version should be >= $min_version"
        else
            assert_equals "$result" "FAIL" "Version $test_version should be < $min_version"
        fi
    done
    
    test_pass "Test completed successfully"
}

# Test version extraction from BASH_VERSION
test_version_extraction() {
    start_test "test_version_extraction"
    
    # Test various BASH_VERSION formats
    local test_cases=(
        "5.3.0(1)-release:5.3.0"
        "5.2.15(1)-release:5.2.15"
        "4.4.20(1)-release:4.4.20"
        "5.3.0-rc1:5.3.0"
        "5.3.0:5.3.0"
    )
    
    for test_case in "${test_cases[@]}"; do
        IFS=':' read -r bash_version expected <<< "$test_case"
        
        # Extract version
        local extracted=$(echo "$bash_version" | sed -E 's/^([0-9]+\.[0-9]+\.[0-9]+).*/\1/')
        
        assert_equals "$extracted" "$expected" "Should extract $expected from $bash_version"
    done
    
    test_pass "Test completed successfully"
}

# Test error handling for old bash versions
test_old_bash_error_handling() {
    start_test "test_old_bash_error_handling"
    
    # Create test script that simulates old bash
    cat > "$TEST_TMP/old_bash_test.sh" << 'EOF'
#!/usr/bin/env bash
# Simulate old bash version
BASH_VERSION="3.2.57(1)-release"
MINIMUM_BASH_VERSION="5.3.0"

# Simple version check
if [[ "${BASH_VERSION%%.*}" -lt "${MINIMUM_BASH_VERSION%%.*}" ]]; then
    echo "ERROR: This script requires bash version $MINIMUM_BASH_VERSION or higher."
    echo "Current version: $BASH_VERSION"
    echo "Please upgrade bash before continuing."
    exit 1
fi

echo "SHOULD_NOT_REACH_HERE"
EOF
    
    chmod +x "$TEST_TMP/old_bash_test.sh"
    
    # Test should exit with error
    local output
    local exit_code
    
    output=$("$TEST_TMP/old_bash_test.sh" 2>&1) || exit_code=$?
    
    assert_equals "$exit_code" "1" "Should exit with code 1 for old bash"
    assert_contains "$output" "ERROR: This script requires bash version" "Should show error message"
    assert_not_contains "$output" "SHOULD_NOT_REACH_HERE" "Should not continue execution"
    
    test_pass "Test completed successfully"
}

# Test version validation in deployment scripts
test_deployment_script_validation() {
    start_test "test_deployment_script_validation"
    
    # Check that deployment scripts have version validation
    local deployment_scripts=(
        "$PROJECT_ROOT/scripts/aws-deployment-modular.sh"
        "$PROJECT_ROOT/scripts/aws-deployment-v2-simple.sh"
    )
    
    for script in "${deployment_scripts[@]}"; do
        if [[ -f "$script" ]]; then
            # Check for version validation
            if grep -q "MINIMUM_BASH_VERSION" "$script"; then
                test_pass "$(basename "$script") has version validation"
            else
                test_fail "$(basename "$script") missing version validation"
            fi
            
            # Check for proper error handling
            if grep -q "bash version.*or higher" "$script"; then
                test_pass "$(basename "$script") has proper error message"
            else
                test_fail "$(basename "$script") missing proper error message"
            fi
        fi
    done
    
    test_pass "Test completed successfully"
}

# Test version check in library modules
test_library_version_checks() {
    start_test "test_library_version_checks"
    
    # Critical libraries that should have version checks
    local critical_libs=(
        "$LIB_DIR/associative-arrays.sh"
        "$LIB_DIR/spot-instance.sh"
        "$LIB_DIR/config-management.sh"
    )
    
    for lib in "${critical_libs[@]}"; do
        if [[ -f "$lib" ]]; then
            if grep -q "BASH_VERSION" "$lib" || grep -q "bash.*5\.[0-9]" "$lib"; then
                test_pass "$(basename "$lib") has version awareness"
            else
                test_warn "$(basename "$lib") may need version check"
            fi
        fi
    done
    
    test_pass "Test completed successfully"
}

# Test upgrade instructions validation
test_upgrade_instructions() {
    start_test "test_upgrade_instructions"
    
    # Test that upgrade instructions work
    local platforms=("macos" "ubuntu" "amazonlinux")
    
    for platform in "${platforms[@]}"; do
        case "$platform" in
            macos)
                # Check Homebrew command format
                local cmd="brew install bash"
                assert_not_empty "$cmd" "macOS upgrade command should exist"
                ;;
            ubuntu)
                # Check apt command format
                local cmd="apt install bash"
                assert_not_empty "$cmd" "Ubuntu upgrade command should exist"
                ;;
            amazonlinux)
                # Check compilation instructions exist
                local cmd="wget https://ftp.gnu.org/gnu/bash/bash-5.3.tar.gz"
                assert_not_empty "$cmd" "Amazon Linux compilation command should exist"
                ;;
        esac
    done
    
    test_pass "Test completed successfully"
}

# Test EC2 user data bash installation
test_ec2_userdata_bash_install() {
    start_test "test_ec2_userdata_bash_install"
    
    # Check if user data includes bash installation
    local userdata_file="$PROJECT_ROOT/terraform/user-data.sh"
    
    if [[ -f "$userdata_file" ]]; then
        if grep -q "bash-5.3" "$userdata_file"; then
            test_pass "EC2 user data includes bash 5.3 installation"
        else
            test_fail "EC2 user data missing bash 5.3 installation"
        fi
    else
        test_warn "User data file not found at expected location"
    fi
    
    test_pass "Test completed successfully"
}

# Test associative array support detection
test_associative_array_support() {
    start_test "test_associative_array_support"
    
    # Test associative array declaration
    cat > "$TEST_TMP/aa_test.sh" << 'EOF'
#!/usr/bin/env bash

# Try to declare associative array
if declare -A test_array 2>/dev/null; then
    test_array["key"]="value"
    if [[ "${test_array["key"]}" == "value" ]]; then
        echo "ASSOCIATIVE_ARRAYS_SUPPORTED"
    else
        echo "ASSOCIATIVE_ARRAYS_BROKEN"
    fi
else
    echo "ASSOCIATIVE_ARRAYS_NOT_SUPPORTED"
fi
EOF
    
    chmod +x "$TEST_TMP/aa_test.sh"
    local result=$("$TEST_TMP/aa_test.sh")
    
    # Current bash should support associative arrays
    if [[ "${BASH_VERSION%%.*}" -ge 4 ]]; then
        assert_equals "$result" "ASSOCIATIVE_ARRAYS_SUPPORTED" "Bash 4+ should support associative arrays"
    else
        assert_equals "$result" "ASSOCIATIVE_ARRAYS_NOT_SUPPORTED" "Bash 3 should not support associative arrays"
    fi
    
    test_pass "Test completed successfully"
}

# Test version-specific feature detection
test_version_feature_detection() {
    start_test "test_version_feature_detection"
    
    # Features by version
    local features=(
        "4.0:associative_arrays"
        "4.2:declare_-g"
        "4.3:nameref_variables"
        "5.0:wait_-n"
        "5.1:PROMPT_COMMANDS"
    )
    
    for feature_spec in "${features[@]}"; do
        IFS=':' read -r min_version feature_name <<< "$feature_spec"
        
        # Create feature test
        case "$feature_name" in
            associative_arrays)
                if [[ "${BASH_VERSION%%.*}" -ge "${min_version%%.*}" ]]; then
                    declare -A test_aa 2>/dev/null && test_pass "$feature_name supported" || test_fail "$feature_name not supported"
                fi
                ;;
            nameref_variables)
                if [[ "${BASH_VERSION%%.*}" -ge "${min_version%%.*}" ]]; then
                    (declare -n test_ref 2>/dev/null) && test_pass "$feature_name supported" || test_warn "$feature_name may not be supported"
                fi
                ;;
        esac
    done
    
    test_pass "Test completed successfully"
}

# Test CI/CD bash version requirements
test_cicd_requirements() {
    start_test "test_cicd_requirements"
    
    # Check GitHub Actions workflow if exists
    local workflow_dir="$PROJECT_ROOT/.github/workflows"
    
    if [[ -d "$workflow_dir" ]]; then
        for workflow in "$workflow_dir"/*.yml "$workflow_dir"/*.yaml; do
            if [[ -f "$workflow" ]]; then
                if grep -q "bash.*5\.[0-9]" "$workflow" || grep -q "brew install bash" "$workflow"; then
                    test_pass "$(basename "$workflow") has bash version consideration"
                else
                    test_warn "$(basename "$workflow") may need bash version setup"
                fi
            fi
        done
    else
        test_warn "No GitHub Actions workflows found"
    fi
    
    test_pass "Test completed successfully"
}

# Run all tests
run_test_suite() {
    test_minimum_version_validation
    test_version_extraction
    test_old_bash_error_handling
    test_deployment_script_validation
    test_library_version_checks
    test_upgrade_instructions
    test_ec2_userdata_bash_install
    test_associative_array_support
    test_version_feature_detection
    test_cicd_requirements
}

# Execute test suite
run_test_suite

# Generate test report
# Show test summary
test_cleanup