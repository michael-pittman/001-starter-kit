#!/usr/bin/env bash
# Comprehensive bash version validation tests
# Tests version checking, feature detection, and script compliance

set -euo pipefail

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Test counters
TESTS_PASSED=0
TESTS_FAILED=0
TESTS_WARNED=0

# Helper functions
pass() {
    echo -e "${GREEN}✓${NC} $1"
    ((TESTS_PASSED++))
}

fail() {
    echo -e "${RED}✗${NC} $1"
    ((TESTS_FAILED++))
}

warn() {
    echo -e "${YELLOW}⚠${NC} $1"
    ((TESTS_WARNED++))
}

info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

section() {
    echo -e "\n${BLUE}=== $1 ===${NC}"
}

# Version comparison function
version_compare() {
    local v1=$1 v2=$2
    local IFS=.
    local i v1_parts=($v1) v2_parts=($v2)
    
    # Fill empty positions with zeros
    for ((i=${#v1_parts[@]}; i<${#v2_parts[@]}; i++)); do
        v1_parts[i]=0
    done
    
    for ((i=0; i<${#v1_parts[@]}; i++)); do
        if [[ -z ${v2_parts[i]} ]]; then
            v2_parts[i]=0
        fi
        
        if ((10#${v1_parts[i]} > 10#${v2_parts[i]})); then
            return 0
        fi
        
        if ((10#${v1_parts[i]} < 10#${v2_parts[i]})); then
            return 1
        fi
    done
    
    return 0
}

# Extract version from string
extract_version() {
    echo "$1" | sed -E 's/^([0-9]+\.[0-9]+\.[0-9]+).*/\1/'
}

echo "╔══════════════════════════════════════════════════════╗"
echo "║       Bash Version Validation Test Suite             ║"
echo "╚══════════════════════════════════════════════════════╝"

# Test 1: Current Environment
section "Current Environment Analysis"

current_version=$(extract_version "$BASH_VERSION")
info "Current bash version: $BASH_VERSION"
info "Extracted version: $current_version"
info "Major version: ${BASH_VERSION%%.*}"

if version_compare "$current_version" "5.3.0"; then
    pass "Current bash ($current_version) meets minimum requirement (5.3.0)"
else
    fail "Current bash ($current_version) does not meet minimum requirement (5.3.0)"
fi

# Test 2: Feature Detection
section "Bash Feature Detection"

# Associative arrays (bash 4.0+)
if declare -A test_aa 2>/dev/null; then
    test_aa["key"]="value"
    if [[ "${test_aa["key"]}" == "value" ]]; then
        pass "Associative arrays fully functional (bash 4.0+)"
    else
        fail "Associative arrays declared but not functional"
    fi
else
    fail "Associative arrays not supported"
fi

# Nameref variables (bash 4.3+)
if (declare -n test_ref 2>/dev/null); then
    pass "Nameref variables supported (bash 4.3+)"
else
    warn "Nameref variables not supported"
fi

# Process substitution
if echo "test" | cat <(echo "process substitution"); then
    pass "Process substitution supported"
else
    fail "Process substitution not supported"
fi

# Test 3: Deployment Script Validation
section "Deployment Script Version Checks"

check_script() {
    local script="$1"
    local basename=$(basename "$script")
    
    if [[ ! -f "$PROJECT_ROOT/$script" ]]; then
        warn "$basename not found"
        return
    fi
    
    local has_check=false
    local check_type=""
    
    if grep -q "MINIMUM_BASH_VERSION" "$PROJECT_ROOT/$script"; then
        has_check=true
        check_type="MINIMUM_BASH_VERSION"
    elif grep -q "BASH_MAJOR.*5" "$PROJECT_ROOT/$script"; then
        has_check=true
        check_type="BASH_MAJOR check"
    elif grep -qE "bash.*5\.[0-9]" "$PROJECT_ROOT/$script"; then
        has_check=true
        check_type="version comment"
    fi
    
    if [[ "$has_check" == "true" ]]; then
        pass "$basename has version validation ($check_type)"
        
        # Check for proper error handling
        if grep -q "exit 1" "$PROJECT_ROOT/$script"; then
            pass "$basename exits on version mismatch"
        else
            warn "$basename may not exit properly on version mismatch"
        fi
    else
        fail "$basename missing version validation"
    fi
}

check_script "scripts/aws-deployment-modular.sh"
check_script "scripts/aws-deployment-v2-simple.sh"
check_script "scripts/deploy-spot-cdn-enhanced.sh"

# Test 4: Library Modernization Check
section "Library Modernization Status"

check_library() {
    local lib="$1"
    local basename=$(basename "$lib")
    
    if [[ ! -f "$PROJECT_ROOT/$lib" ]]; then
        warn "$basename not found"
        return
    fi
    
    local features=0
    
    # Check for associative arrays
    if grep -q "declare -A" "$PROJECT_ROOT/$lib"; then
        ((features++))
        info "$basename uses associative arrays"
    fi
    
    # Check for nameref variables
    if grep -q "declare -n" "$PROJECT_ROOT/$lib"; then
        ((features++))
        info "$basename uses nameref variables"
    fi
    
    # Check for modern bash constructs
    if grep -qE "(\[\[|\$\(|mapfile|readarray)" "$PROJECT_ROOT/$lib"; then
        ((features++))
    fi
    
    if [[ $features -gt 0 ]]; then
        pass "$basename is modernized (uses $features modern features)"
    else
        warn "$basename may need modernization"
    fi
}

check_library "lib/associative-arrays.sh"
check_library "lib/spot-instance.sh"
check_library "lib/config-management.sh"
check_library "lib/deployment-state-manager.sh"
check_library "lib/aws-resource-manager.sh"

# Test 5: EC2 User Data Validation
section "EC2 User Data Bash Installation"

userdata_files=(
    "terraform/user-data.sh"
    "lib/modules/deployment/userdata.sh"
)

for userdata in "${userdata_files[@]}"; do
    if [[ -f "$PROJECT_ROOT/$userdata" ]]; then
        if grep -q "bash-5.3" "$PROJECT_ROOT/$userdata"; then
            pass "$(basename "$userdata") includes bash 5.3 installation"
        else
            fail "$(basename "$userdata") missing bash 5.3 installation"
        fi
    else
        warn "$userdata not found"
    fi
done

# Test 6: Documentation Check
section "Documentation Validation"

doc_files=(
    "CLAUDE.md"
    "README.md"
    "docs/OS-COMPATIBILITY.md"
)

for doc in "${doc_files[@]}"; do
    if [[ -f "$PROJECT_ROOT/$doc" ]]; then
        if grep -qE "(bash.*5\.[0-9]|Bash 5\.3)" "$PROJECT_ROOT/$doc"; then
            pass "$doc mentions bash 5.3+ requirement"
        else
            warn "$doc may need bash version documentation"
        fi
    fi
done

# Test 7: Version Comparison Tests
section "Version Comparison Logic Tests"

test_comparison() {
    local v1=$1 v2=$2 expected=$3
    
    if version_compare "$v1" "$v2"; then
        result="true"
    else
        result="false"
    fi
    
    if [[ "$result" == "$expected" ]]; then
        pass "Version comparison: $v1 >= $v2 is $expected"
    else
        fail "Version comparison: $v1 >= $v2 expected $expected, got $result"
    fi
}

test_comparison "5.3.0" "5.3.0" "true"
test_comparison "5.4.0" "5.3.0" "true"
test_comparison "5.2.0" "5.3.0" "false"
test_comparison "6.0.0" "5.3.0" "true"
test_comparison "5.3.1" "5.3.0" "true"
test_comparison "5.3.0" "5.3.1" "false"

# Test 8: Critical Scripts Check
section "Critical Script Analysis"

critical_scripts=(
    "Makefile"
    "scripts/check-dependencies.sh"
    "scripts/validate-environment.sh"
    "tools/install-deps.sh"
)

for script in "${critical_scripts[@]}"; do
    if [[ -f "$PROJECT_ROOT/$script" ]]; then
        # Check if script handles bash installation
        if grep -qE "(brew install bash|apt.*install.*bash|bash-5\.3)" "$PROJECT_ROOT/$script"; then
            pass "$script handles bash installation"
        else
            info "$script does not handle bash installation"
        fi
    fi
done

# Summary
echo -e "\n╔══════════════════════════════════════════════════════╗"
echo "║                   Test Summary                       ║"
echo "╚══════════════════════════════════════════════════════╝"
echo -e "  ${GREEN}Passed: $TESTS_PASSED${NC}"
echo -e "  ${RED}Failed: $TESTS_FAILED${NC}"
echo -e "  ${YELLOW}Warnings: $TESTS_WARNED${NC}"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo -e "${GREEN}✓ All critical tests passed!${NC}"
    if [[ $TESTS_WARNED -gt 0 ]]; then
        echo -e "${YELLOW}  Note: $TESTS_WARNED warnings should be reviewed${NC}"
    fi
    exit 0
else
    echo -e "${RED}✗ $TESTS_FAILED tests failed!${NC}"
    exit 1
fi