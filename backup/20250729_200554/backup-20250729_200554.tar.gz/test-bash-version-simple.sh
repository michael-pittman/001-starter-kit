#!/usr/bin/env bash
# Simple bash version validation tests
# Tests version checking functionality without complex framework dependencies

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test functions
pass() {
    echo -e "${GREEN}✓${NC} $1"
    ((TESTS_PASSED++))
}

fail() {
    echo -e "${RED}✗${NC} $1"
    ((TESTS_FAILED++))
}

warn() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# Version comparison function
version_compare() {
    local v1=$1 v2=$2
    local IFS=.
    local i v1_parts=($v1) v2_parts=($v2)
    
    # Fill empty positions with zeros
    for ((i=${#v1_parts[@]}; i<${#v2_parts[@]}; i++)); do
        v1_parts[i]=0
    done
    
    for ((i=0; i<${#v1_parts[@]}; i++)); do
        if [[ -z ${v2_parts[i]} ]]; then
            v2_parts[i]=0
        fi
        
        if ((10#${v1_parts[i]} > 10#${v2_parts[i]})); then
            return 0
        fi
        
        if ((10#${v1_parts[i]} < 10#${v2_parts[i]})); then
            return 1
        fi
    done
    
    return 0
}

echo "Running Bash Version Validation Tests"
echo "====================================="

# Test 1: Version comparison logic
echo -e "\n1. Testing version comparison logic..."
((TESTS_RUN++))

test_version_compare() {
    local v1=$1 v2=$2 expected=$3 desc=$4
    
    if version_compare "$v1" "$v2"; then
        result="true"
    else
        result="false"
    fi
    
    if [[ "$result" == "$expected" ]]; then
        pass "$desc: $v1 vs $v2 = $expected"
    else
        fail "$desc: $v1 vs $v2 expected $expected, got $result"
    fi
}

test_version_compare "5.3.0" "5.3.0" "true" "Equal versions"
test_version_compare "5.4.0" "5.3.0" "true" "Higher version"
test_version_compare "5.2.0" "5.3.0" "false" "Lower version"
test_version_compare "5.3.1" "5.3.0" "true" "Higher patch"
test_version_compare "5.3.0" "5.3.1" "false" "Lower patch"

# Test 2: Current bash version
echo -e "\n2. Testing current bash version..."
((TESTS_RUN++))

current_version="${BASH_VERSION%%[^0-9.]*}"
echo "Current bash version: $current_version"

if version_compare "$current_version" "5.3.0"; then
    pass "Current bash ($current_version) meets minimum requirement (5.3.0)"
else
    warn "Current bash ($current_version) does not meet minimum requirement (5.3.0)"
fi

# Test 3: Check deployment scripts
echo -e "\n3. Checking deployment scripts for version validation..."
((TESTS_RUN++))

check_script_version() {
    local script=$1
    local basename=$(basename "$script")
    
    if [[ -f "$script" ]]; then
        if grep -q "MINIMUM_BASH_VERSION" "$script"; then
            pass "$basename has version check"
        else
            fail "$basename missing version check"
        fi
    else
        warn "$basename not found"
    fi
}

check_script_version "scripts/aws-deployment-modular.sh"
check_script_version "scripts/aws-deployment-v2-simple.sh"

# Test 4: Check critical libraries
echo -e "\n4. Checking critical libraries for bash 5.3+ features..."
((TESTS_RUN++))

check_library_features() {
    local lib=$1
    local basename=$(basename "$lib")
    
    if [[ -f "$lib" ]]; then
        if grep -q "declare -A" "$lib"; then
            pass "$basename uses associative arrays (bash 4.0+)"
        fi
        
        if grep -q "declare -n" "$lib"; then
            pass "$basename uses nameref variables (bash 4.3+)"
        fi
    else
        warn "$basename not found"
    fi
}

check_library_features "lib/associative-arrays.sh"
check_library_features "lib/spot-instance.sh"
check_library_features "lib/config-management.sh"

# Test 5: Version extraction patterns
echo -e "\n5. Testing version extraction patterns..."
((TESTS_RUN++))

test_version_extraction() {
    local version_string=$1
    local expected=$2
    
    extracted=$(echo "$version_string" | sed -E 's/^([0-9]+\.[0-9]+\.[0-9]+).*/\1/')
    
    if [[ "$extracted" == "$expected" ]]; then
        pass "Extract $expected from '$version_string'"
    else
        fail "Failed to extract $expected from '$version_string' (got $extracted)"
    fi
}

test_version_extraction "5.3.0(1)-release" "5.3.0"
test_version_extraction "5.2.15(1)-release" "5.2.15"
test_version_extraction "4.4.20(1)-release" "4.4.20"

# Test 6: EC2 user data check
echo -e "\n6. Checking EC2 user data for bash installation..."
((TESTS_RUN++))

if [[ -f "terraform/user-data.sh" ]]; then
    if grep -q "bash-5.3" "terraform/user-data.sh"; then
        pass "EC2 user data includes bash 5.3 installation"
    else
        fail "EC2 user data missing bash 5.3 installation"
    fi
else
    warn "terraform/user-data.sh not found"
fi

# Summary
echo -e "\n====================================="
echo "Test Summary:"
echo "  Total tests: $TESTS_RUN"
echo -e "  ${GREEN}Passed: $TESTS_PASSED${NC}"
echo -e "  ${RED}Failed: $TESTS_FAILED${NC}"

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo -e "\n${GREEN}All tests passed!${NC}"
    exit 0
else
    echo -e "\n${RED}Some tests failed!${NC}"
    exit 1
fi