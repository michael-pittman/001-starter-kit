#!/usr/bin/env bash

# Library Loader Template for GeuseMaker
# Provides standardized module loading with proper error handling and path resolution
# Usage: source this file at the beginning of your script

set -euo pipefail

# Global variables for library loading
declare -g LIBRARY_LOADER_VERSION="1.0.0"
declare -g LIBRARY_LOADER_LOADED=true
declare -gA LOADED_MODULES=()
declare -gA MODULE_LOAD_TIMES=()
declare -g LIBRARY_LOAD_ERRORS=()

# Determine script location and project root
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    echo "Error: library-loader.sh must be sourced, not executed directly" >&2
    exit 1
fi

# Robust path resolution that works from any location
resolve_script_dir() {
    local source="${BASH_SOURCE[1]:-${BASH_SOURCE[0]}}"
    local dir
    
    # Handle symlinks
    while [[ -L "$source" ]]; do
        dir="$(cd -P "$(dirname "$source")" && pwd)"
        source="$(readlink "$source")"
        [[ $source != /* ]] && source="$dir/$source"
    done
    
    dir="$(cd -P "$(dirname "$source")" && pwd)"
    echo "$dir"
}

# Find project root by looking for marker files
find_project_root() {
    local current_dir="$1"
    local marker_files=("CLAUDE.md" "Makefile" ".git")
    
    while [[ "$current_dir" != "/" ]]; do
        for marker in "${marker_files[@]}"; do
            if [[ -e "$current_dir/$marker" ]]; then
                echo "$current_dir"
                return 0
            fi
        done
        current_dir="$(dirname "$current_dir")"
    done
    
    # Fallback: assume we're somewhere under the project
    echo "$(cd "$1/../.." && pwd)"
}

# Initialize paths
SCRIPT_DIR="$(resolve_script_dir)"
PROJECT_ROOT="$(find_project_root "$SCRIPT_DIR")"
LIB_DIR="$PROJECT_ROOT/lib"
MODULES_DIR="$LIB_DIR/modules"

# Export for child scripts
export PROJECT_ROOT LIB_DIR MODULES_DIR


# Enhanced source with error handling and tracking
safe_source() {
    local file="$1"
    local required="${2:-true}"
    local description="${3:-}"
    local start_time=$(date +%s.%N)
    
    # Check if already loaded
    if [[ -n "${LOADED_MODULES[$file]:-}" ]]; then
        return 0
    fi
    
    # Resolve relative paths
    if [[ ! "$file" =~ ^/ ]]; then
        # Try multiple base paths
        local bases=("$LIB_DIR" "$MODULES_DIR" "$PROJECT_ROOT" "$SCRIPT_DIR")
        local found=false
        
        for base in "${bases[@]}"; do
            if [[ -f "$base/$file" ]]; then
                file="$base/$file"
                found=true
                break
            fi
        done
        
        if [[ "$found" != "true" && -f "$file" ]]; then
            file="$(cd "$(dirname "$file")" && pwd)/$(basename "$file")"
        fi
    fi
    
    # Check if file exists
    if [[ ! -f "$file" ]]; then
        local error_msg="Library not found: $file"
        [[ -n "$description" ]] && error_msg="$description library not found: $file"
        
        if [[ "$required" == "true" ]]; then
            echo "Error: $error_msg" >&2
            LIBRARY_LOAD_ERRORS+=("$error_msg")
            return 1
        else
            echo "Warning: $error_msg (optional, continuing)" >&2
            return 0
        fi
    fi
    
    # Source the file with error handling
    if source "$file" 2>/dev/null; then
        LOADED_MODULES["$file"]=1
        local end_time=$(date +%s.%N)
        MODULE_LOAD_TIMES["$file"]=$(echo "$end_time - $start_time" | bc)
        [[ -n "$description" ]] && echo "Loaded: $description"
        return 0
    else
        local error_msg="Failed to load: $file"
        [[ -n "$description" ]] && error_msg="Failed to load $description: $file"
        echo "Error: $error_msg" >&2
        LIBRARY_LOAD_ERRORS+=("$error_msg")
        return 1
    fi
}

# Load module with dependency resolution
load_module() {
    local module_name="$1"
    local module_path="modules/$module_name"
    
    # Check for .sh extension
    [[ ! "$module_path" =~ \.sh$ ]] && module_path="${module_path}.sh"
    
    safe_source "$module_path" true "Module $module_name"
}

# Batch load modules
load_modules() {
    local modules=("$@")
    local failed=0
    
    for module in "${modules[@]}"; do
        if ! load_module "$module"; then
            ((failed++))
        fi
    done
    
    return $failed
}

# Standard library loading order
load_standard_libraries() {
    local libraries=(
        "aws-deployment-common.sh:Core logging and prerequisites"
        "error-handling.sh:Error handling and cleanup"
        "associative-arrays.sh:Enhanced data structures:optional"
        "aws-cli-v2.sh:AWS CLI integration:optional"
    )
    
    local failed=0
    for lib_spec in "${libraries[@]}"; do
        local lib_file="${lib_spec%%:*}"
        local lib_desc="${lib_spec#*:}"
        lib_desc="${lib_desc%%:*}"
        local lib_req="true"
        [[ "$lib_spec" =~ :optional$ ]] && lib_req="false"
        
        if ! safe_source "$lib_file" "$lib_req" "$lib_desc"; then
            [[ "$lib_req" == "true" ]] && ((failed++))
        fi
    done
    
    return $failed
}

# Load core modules in dependency order
load_core_modules() {
    local core_modules=(
        "core/variables"
        "core/errors"
        "core/registry"
        "core/validation"
        "core/logging"
    )
    
    echo "Loading core modules..."
    load_modules "${core_modules[@]}"
}

# Load infrastructure modules
load_infrastructure_modules() {
    local infra_modules=(
        "infrastructure/vpc"
        "infrastructure/ec2"
        "infrastructure/alb"
        "infrastructure/cloudfront"
        "infrastructure/compute"
    )
    
    echo "Loading infrastructure modules..."
    load_modules "${infra_modules[@]}"
}

# Load application modules
load_application_modules() {
    local app_modules=(
        "application/service_config"
        "monitoring/metrics"
        "deployment/state"
        "deployment/orchestrator"
        "deployment/rollback"
    )
    
    echo "Loading application modules..."
    load_modules "${app_modules[@]}"
}

# Print loading summary
print_loading_summary() {
    echo "=== Library Loading Summary ==="
    echo "Loaded ${#LOADED_MODULES[@]} modules successfully"
    
    if [[ ${#MODULE_LOAD_TIMES[@]} -gt 0 ]]; then
        echo -e "\nLoad times:"
        for module in "${!MODULE_LOAD_TIMES[@]}"; do
            printf "  %-50s %.3fs\n" "$(basename "$module")" "${MODULE_LOAD_TIMES[$module]}"
        done
    fi
    
    if [[ ${#LIBRARY_LOAD_ERRORS[@]} -gt 0 ]]; then
        echo -e "\nErrors encountered:"
        for error in "${LIBRARY_LOAD_ERRORS[@]}"; do
            echo "  - $error"
        done
        return 1
    fi
    
    echo "=== Loading complete ==="
    return 0
}

# Recovery mechanism for missing modules
attempt_module_recovery() {
    local module="$1"
    local recovery_paths=(
        "$PROJECT_ROOT/lib/modules/$module"
        "$PROJECT_ROOT/lib/$module"
        "$SCRIPT_DIR/../lib/$module"
        "$SCRIPT_DIR/../lib/modules/$module"
    )
    
    for path in "${recovery_paths[@]}"; do
        if [[ -f "$path" ]]; then
            echo "Found module at alternate location: $path"
            safe_source "$path" true
            return $?
        fi
    done
    
    echo "Could not recover module: $module" >&2
    return 1
}

# Template function for script initialization
initialize_script() {
    local script_name="${1:-$(basename "${BASH_SOURCE[1]}")}"
    local required_modules=("${@:2}")
    
    echo "Initializing $script_name..."
    
    # Load standard libraries
    if ! load_standard_libraries; then
        echo "Error: Failed to load required standard libraries" >&2
        return 1
    fi
    
    # Load requested modules
    if [[ ${#required_modules[@]} -gt 0 ]]; then
        echo "Loading required modules: ${required_modules[*]}"
        if ! load_modules "${required_modules[@]}"; then
            echo "Error: Failed to load required modules" >&2
            return 1
        fi
    fi
    
    echo "$script_name initialization complete"
    return 0
}

# Load optional library with graceful failure
load_optional_library() {
    local library="$1"
    local description="${2:-Optional library}"
    
    # Try to load the library, but don't fail if it doesn't exist
    if safe_source "$library" false "$description"; then
        return 0
    else
        # Log that the optional library wasn't loaded, but don't treat as error
        echo "Note: $description not available ($library)" >&2
        return 1
    fi
}

# Provide usage example if sourced directly
if [[ "${BASH_SOURCE[0]}" == "${BASH_SOURCE[-1]}" ]]; then
    cat << 'EOF'
Library Loader Template Usage:

1. Basic usage in your script:
   ```bash
   #!/usr/bin/env bash
   source "$(dirname "${BASH_SOURCE[0]}")/../lib/utils/library-loader.sh"
   
   # Initialize with required modules
   initialize_script "my-script.sh" "core/variables" "infrastructure/vpc"
   ```

2. Custom loading pattern:
   ```bash
   source "$PROJECT_ROOT/lib/utils/library-loader.sh"
   
   # Load standard libraries
   load_standard_libraries
   
   # Load specific modules
   load_modules "core/errors" "infrastructure/ec2"
   
   # Check for errors
   print_loading_summary || exit 1
   ```

3. Advanced usage with error handling:
   ```bash
   source "$lib_loader"
   
   # Try to load optional modules
   safe_source "advanced-features.sh" false "Advanced features"
   
   # Load with recovery
   load_module "infrastructure/alb" || attempt_module_recovery "infrastructure/alb.sh"
   ```

Available functions:
- initialize_script: Complete script initialization
- load_standard_libraries: Load core libraries
- load_modules: Load multiple modules
- safe_source: Source with error handling
- print_loading_summary: Show loading results
- attempt_module_recovery: Try alternate paths

Environment variables set:
- PROJECT_ROOT: Project root directory
- LIB_DIR: Library directory
- MODULES_DIR: Modules directory
- LOADED_MODULES: Associative array of loaded modules
EOF
fi