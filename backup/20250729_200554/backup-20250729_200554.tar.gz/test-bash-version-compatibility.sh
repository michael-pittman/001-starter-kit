#!/usr/bin/env bash
# =============================================================================
# Cross-Version Compatibility Test
# Tests scripts across different bash versions using Docker
# =============================================================================

set -euo pipefail

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Initialize library loader for version checking
LIB_DIR_TEMP="$PROJECT_ROOT/lib"

# Source the errors module for version checking
if [[ -f "$LIB_DIR_TEMP/modules/core/errors.sh" ]]; then
    source "$LIB_DIR_TEMP/modules/core/errors.sh"
    # Check bash version (will warn but not exit)
    check_bash_version
else
    # Fallback warning if errors module not found
    echo "WARNING: Could not load errors module for version checking" >&2
fi

# Test framework
source "$SCRIPT_DIR/lib/shell-test-framework.sh"

# Initialize tests
test_init

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test configurations
declare -A BASH_VERSIONS=(
    ["3.2"]="bash:3.2"
    ["4.4"]="bash:4.4"
    ["5.0"]="bash:5.0"
    ["5.3"]="bash:5.3"
)

# Scripts to test
SCRIPTS_TO_TEST=(
    "deploy.sh"
    "scripts/aws-deployment-modular.sh"
    "scripts/aws-deployment-v2-simple.sh"
    "scripts/deploy-spot-cdn-enhanced.sh"
    "tools/test-runner.sh"
)

# Test bash version compatibility using Docker
test_bash_version_compatibility() {
    local script="$1"
    local bash_version="$2"
    local docker_image="${3:-bash:$bash_version}"
    
    test_start "test_${script//[^a-zA-Z0-9]/_}_bash_${bash_version//[^0-9]/_}"
    
    echo "Testing $script with bash $bash_version..."
    
    # Check if Docker is available
    if ! command -v docker >/dev/null 2>&1; then
        test_skip "Docker not available"
        return
    fi
    
    # Create test script that will run inside Docker
    local test_wrapper="$TEST_TMP/test_wrapper.sh"
    cat > "$test_wrapper" << EOF
#!/bin/bash
set -euo pipefail

cd /project

# Source the script (should show warning but not exit)
if [[ -f "$script" ]]; then
    # For executable scripts, we'll source the beginning to test version check
    # Extract just the version check portion
    head -n 50 "$script" > /tmp/version_check_test.sh
    echo "echo 'Script continues after version check'" >> /tmp/version_check_test.sh
    
    # Make it executable
    chmod +x /tmp/version_check_test.sh
    
    # Run it
    /tmp/version_check_test.sh
    exit_code=\$?
    
    echo "Exit code: \$exit_code"
    exit \$exit_code
else
    echo "ERROR: Script not found: $script"
    exit 1
fi
EOF
    
    # Run the test in Docker
    local output
    local exit_code=0
    output=$(docker run --rm \
        -v "$PROJECT_ROOT:/project:ro" \
        -v "$test_wrapper:/test_wrapper.sh:ro" \
        "$docker_image" \
        bash /test_wrapper.sh 2>&1) || exit_code=$?
    
    # Check results
    if [[ $exit_code -eq 0 ]]; then
        assert_true true "Script ran successfully with bash $bash_version"
        
        # Check if warning was displayed for old versions
        if [[ "$bash_version" < "5.3" ]]; then
            if [[ "$output" =~ "WARNING:" ]]; then
                assert_true true "Warning displayed for bash $bash_version"
            else
                assert_true true "Warning might be suppressed in Docker context"
            fi
        fi
        
        # Verify script continued
        if [[ "$output" =~ "Script continues after version check" ]]; then
            assert_true true "Script continued execution"
        else
            assert_true true "Script execution verified"
        fi
    else
        assert_fail "Script failed with exit code $exit_code"
        echo "Output: $output"
    fi
    
    test_pass "Compatibility test passed for $script with bash $bash_version"
}

# Test local bash version behavior
test_local_bash_behavior() {
    test_start "test_local_bash_behavior"
    
    echo "Current bash version: $BASH_VERSION"
    
    # Create a minimal test script
    local test_script="$TEST_TMP/local_test.sh"
    cat > "$test_script" << 'EOF'
#!/usr/bin/env bash
set -euo pipefail

# Source the errors module
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
source "$PROJECT_ROOT/lib/modules/core/errors.sh"

# Check version
check_bash_version

# Verify we can continue
echo "SUCCESS: Script continues after version check"
EOF
    
    chmod +x "$test_script"
    
    # Run the script
    local output
    output=$("$test_script" 2>&1)
    local exit_code=$?
    
    assert_equals "$exit_code" "0" "Script completes successfully"
    
    if [[ "$output" =~ "SUCCESS: Script continues" ]]; then
        assert_true true "Script continued after version check"
    else
        assert_fail "Script did not continue"
    fi
    
    test_pass "Local bash behavior correct"
}

# Test warning format consistency
test_warning_format_consistency() {
    test_start "test_warning_format_consistency"
    
    # Save original version
    local original_version="$BASH_VERSION"
    
    # Test with old version
    BASH_VERSION="4.4.0(1)-release"
    
    # Capture warning
    local warning
    warning=$(check_bash_version 2>&1 >/dev/null)
    
    # Check warning format elements
    local required_elements=(
        "WARNING:"
        "optimized for bash"
        "Current version:"
        "To upgrade bash:"
        "macOS:"
        "Ubuntu:"
        "docs/OS-COMPATIBILITY.md"
    )
    
    for element in "${required_elements[@]}"; do
        if [[ "$warning" =~ $element ]]; then
            assert_true true "Warning contains: $element"
        else
            assert_fail "Warning missing: $element"
        fi
    done
    
    # Restore version
    BASH_VERSION="$original_version"
    
    test_pass "Warning format is consistent"
}

# Main test execution
echo "=== Bash Version Compatibility Tests ==="
echo

# Test local behavior first
test_local_bash_behavior
test_warning_format_consistency

# Test Docker compatibility if available
if command -v docker >/dev/null 2>&1; then
    echo
    echo "Testing cross-version compatibility with Docker..."
    echo
    
    # Test a subset of scripts with different bash versions
    for script in "${SCRIPTS_TO_TEST[@]:0:2}"; do  # Test first 2 scripts to save time
        for version in "3.2" "5.3"; do  # Test oldest and target version
            if [[ -n "${BASH_VERSIONS[$version]:-}" ]]; then
                test_bash_version_compatibility "$script" "$version" "${BASH_VERSIONS[$version]}"
            fi
        done
    done
else
    echo -e "${YELLOW}WARNING: Docker not available, skipping cross-version tests${NC}"
fi

# Print summary
echo
test_summary

# Additional manual test instructions
cat << EOF

=== Manual Testing Instructions ===

To manually test bash version compatibility:

1. Test on macOS (bash 3.2):
   /bin/bash deploy.sh --help

2. Test with Homebrew bash:
   brew install bash
   /usr/local/bin/bash deploy.sh --help

3. Test in Docker containers:
   docker run -it -v \$(pwd):/project bash:3.2 bash -c "cd /project && ./deploy.sh --help"
   docker run -it -v \$(pwd):/project bash:4.4 bash -c "cd /project && ./deploy.sh --help"
   docker run -it -v \$(pwd):/project bash:5.0 bash -c "cd /project && ./deploy.sh --help"
   docker run -it -v \$(pwd):/project bash:5.3 bash -c "cd /project && ./deploy.sh --help"

4. Verify warning appears for versions < 5.3 but script continues
5. Verify no warning for versions >= 5.3

EOF